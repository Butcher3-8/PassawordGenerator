import random
import string
import tkinter as tk
from tkinter import messagebox

def rastgele_sifre_uret(hane_sayisi):
    karakterler = string.ascii_letters + string.digits + string.punctuation
    sifre = ''.join(random.choice(karakterler) for _ in range(hane_sayisi))
    return sifre

def sifre_uret():
    try:
        hane_sayisi = int(entry.get())
        if hane_sayisi < 1:
            messagebox.showerror("Hata", "Şifre uzunluğu 1'den büyük olmalıdır.")
            return
        
        yeni_sifre = rastgele_sifre_uret(hane_sayisi)
        messagebox.showinfo("Üretilen Şifre", yeni_sifre)
    except ValueError:
        messagebox.showerror("Hata", "Lütfen geçerli bir sayı girin.")

# Ana pencereyi oluştur
root = tk.Tk()
root.title("Şifre Üretici")
root.geometry("400x200")  # Pencere boyutu
root.config(bg="#f0f0f0")  # Arka plan rengi

# Başlık etiketi
label = tk.Label(root, text="Kaç haneli bir şifre istiyorsunuz?", bg="#f0f0f0", font=("Helvetica", 14))
label.pack(pady=20)

# Girdi alanı
entry = tk.Entry(root, font=("Helvetica", 12))
entry.pack(pady=10)

# Buton
button = tk.Button(root, text="Şifre Üret", command=sifre_uret, bg="#4CAF50", fg="white", font=("Helvetica", 12))
button.pack(pady=20)

# Pencereyi çalıştır
root.mainloop()
